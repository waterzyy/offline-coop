/*
 * XInputBlock.asi — XInput proxy / isolator for Player 2.
 *
 * Strategy: this ASI loads *early* via ASI loader and installs an inline hook
 * on the real xinput1_4.dll!XInputGetState/XInputSetState inside the GTA process.
 *   - Pad 0 (Controller 1) -> passed through unmodified (kb/mouse/player1 pad)
 *   - Pad 1 (Controller 2) -> copied into a cross-process shared-memory slot for
 *                             OfflineCoop.dll to consume; then the pad state
 *                             returned to GTA is zeroed out, so GTA never sees
 *                             those inputs and they don't bleed into P1.
 *   - Pads 2,3             -> passed through.
 *
 * This fixes the original bug where P2 buttons leaked into P1 controls.
 *
 * Build (MSVC x64):
 *     cl /nologo /W3 /O2 /LD /D_UNICODE /DUNICODE dllmain.cpp
 *        /Fe:XInputBlock.asi xinput9_1_0.lib user32.lib kernel32.lib
 *  (or rename to XInputBlock.asi after build).
 */
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <cstdint>
#include <cstring>

// ---- XInput types (avoid pulling XInput.h which isn't in SDK here) ----
struct XINPUT_GAMEPAD {
    uint16_t wButtons;
    uint8_t  bLeftTrigger;
    uint8_t  bRightTrigger;
    int16_t  sThumbLX; int16_t sThumbLY;
    int16_t  sThumbRX; int16_t sThumbRY;
};
struct XINPUT_STATE { uint32_t dwPacketNumber; XINPUT_GAMEPAD Gamepad; };
typedef DWORD (WINAPI* XInputGetState_t)(DWORD dwUserIndex, XINPUT_STATE* pState);
typedef DWORD (WINAPI* XInputSetState_t)(DWORD dwUserIndex, void* pVibration);

// Shared state with OfflineCoopMod.asi
#pragma pack(push, 1)
struct SharedState {
    uint32_t magic;
    uint32_t version;
    volatile LONG   splitEnabled;
    volatile LONG   p2Exists;
    uint32_t        orientation;
    volatile LONG   renderingPass;
    uint32_t p1viewportX, p1viewportY, p1viewportW, p1viewportH;
    uint32_t p2viewportX, p2viewportY, p2viewportW, p2viewportH;
    uint16_t p2Buttons;
    uint8_t  p2LeftTrigger;
    uint8_t  p2RightTrigger;
    int16_t  p2ThumbLX; int16_t p2ThumbLY;
    int16_t  p2ThumbRX; int16_t p2ThumbRY;
};
#pragma pack(pop)

static HMODULE        g_hRealXInput    = nullptr;
static XInputGetState_t oXInputGetState = nullptr;
static XInputSetState_t oXInputSetState = nullptr;
static HANDLE         g_hMap           = nullptr;
static SharedState*   g_pState         = nullptr;

static const wchar_t* MAP_NAME = L"Local\\OfflineCoopState";

static void LoadRealXInput()
{
    // Try the versions the game actually loads in order.
    for (const wchar_t* dll : {L"xinput1_4.dll", L"xinput1_3.dll", L"xinput9_1_0.dll"}) {
        g_hRealXInput = LoadLibraryW(dll);
        if (g_hRealXInput) break;
    }
    if (g_hRealXInput) {
        oXInputGetState = (XInputGetState_t)GetProcAddress(g_hRealXInput, "XInputGetState");
        oXInputSetState = (XInputSetState_t)GetProcAddress(g_hRealXInput, "XInputSetState");
    }
}

// Hooked XInputGetState: intercept Pad-1, publish to shared memory, zero the result
static DWORD WINAPI XInputGetState_Hook(DWORD dwUserIndex, XINPUT_STATE* pState)
{
    if (!oXInputGetState) return ERROR_DEVICE_NOT_CONNECTED;
    DWORD res = oXInputGetState(dwUserIndex, pState);
    if (res != ERROR_SUCCESS || !pState) return res;

    if (dwUserIndex == 1) {
        // Controller 2 (Player 2) -> capture + suppress from the game
        if (g_pState) {
            g_pState->p2Buttons      = pState->Gamepad.wButtons;
            g_pState->p2LeftTrigger  = pState->Gamepad.bLeftTrigger;
            g_pState->p2RightTrigger = pState->Gamepad.bRightTrigger;
            g_pState->p2ThumbLX = pState->Gamepad.sThumbLX;
            g_pState->p2ThumbLY = pState->Gamepad.sThumbLY;
            g_pState->p2ThumbRX = pState->Gamepad.sThumbRX;
            g_pState->p2ThumbRY = pState->Gamepad.sThumbRY;
        }
        // Zero out so GTA doesn't act on P2 buttons via global input processing
        memset(pState, 0, sizeof(*pState));
        return ERROR_DEVICE_NOT_CONNECTED;
    }
    return res;
}

static DWORD WINAPI XInputSetState_Hook(DWORD dwUserIndex, void* pVib)
{
    if (!oXInputSetState) return ERROR_DEVICE_NOT_CONNECTED;
    // Do not forward vibration calls to pad 1 from the game (they'd be for P1).
    // The C# script can vibrate pad 1 directly through this shared memory path
    // in a future build; for now we block accidental vibration bleed.
    if (dwUserIndex == 1) return ERROR_SUCCESS;
    return oXInputSetState(dwUserIndex, pVib);
}

// ---- Simple IAT hook on ourselves (and on the GTA process) ----
static void* FindIATEntry(HMODULE mod, const char* dllName, const char* procName)
{
    if (!mod) return nullptr;
    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)mod;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((uint8_t*)mod + dos->e_lfanew);
    auto& imp = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (imp.VirtualAddress == 0) return nullptr;
    for (PIMAGE_IMPORT_DESCRIPTOR desc = (PIMAGE_IMPORT_DESCRIPTOR)((uint8_t*)mod + imp.VirtualAddress);
         desc->Name; ++desc)
    {
        const char* name = (const char*)((uint8_t*)mod + desc->Name);
        if (_stricmp(name, dllName) != 0) continue;

        if (desc->OriginalFirstThunk) {
            PIMAGE_THUNK_DATA oft = (PIMAGE_THUNK_DATA)((uint8_t*)mod + desc->OriginalFirstThunk);
            PIMAGE_THUNK_DATA ft  = (PIMAGE_THUNK_DATA)((uint8_t*)mod + desc->FirstThunk);
            for (; oft->u1.AddressOfData; ++oft, ++ft) {
                if (IMAGE_SNAP_BY_ORDINAL(oft->u1.Ordinal)) continue;
                PIMAGE_IMPORT_BY_NAME ibn = (PIMAGE_IMPORT_BY_NAME)((uint8_t*)mod + oft->u1.AddressOfData);
                if (strcmp(ibn->Name, procName) == 0) return &ft->u1.Function;
            }
        }
    }
    return nullptr;
}

static bool PatchIAT(void* pEntry, void* newFunc, void** ppOld)
{
    if (!pEntry) return false;
    DWORD oldP;
    if (!VirtualProtect(pEntry, sizeof(void*), PAGE_READWRITE, &oldP)) return false;
    if (ppOld) *ppOld = *(void**)pEntry;
    *(void**)pEntry = newFunc;
    VirtualProtect(pEntry, sizeof(void*), oldP, &oldP);
    return true;
}

static void InstallHooksInModule(HMODULE mod)
{
    // Hook XInputGetState and XInputSetState if the module imports them
    void* e = FindIATEntry(mod, "xinput1_4.dll",  "XInputGetState");
    if (!e) e = FindIATEntry(mod, "xinput1_3.dll",  "XInputGetState");
    if (!e) e = FindIATEntry(mod, "xinput9_1_0.dll", "XInputGetState");
    if (e)  PatchIAT(e, (void*)XInputGetState_Hook, (void**)&oXInputGetState);

    void* s = FindIATEntry(mod, "xinput1_4.dll",  "XInputSetState");
    if (!s) s = FindIATEntry(mod, "xinput1_3.dll",  "XInputSetState");
    if (!s) s = FindIATEntry(mod, "xinput9_1_0.dll", "XInputSetState");
    if (s)  PatchIAT(s, (void*)XInputSetState_Hook, (void**)&oXInputSetState);
}

static DWORD WINAPI InitThread(LPVOID)
{
    LoadRealXInput();
    if (!oXInputGetState || !oXInputSetState) return 1;

    g_hMap = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, MAP_NAME);
    if (g_hMap) {
        g_pState = (SharedState*)MapViewOfFile(g_hMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedState));
    } else {
        g_hMap = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE,
                                    0, sizeof(SharedState), MAP_NAME);
        if (g_hMap) {
            g_pState = (SharedState*)MapViewOfFile(g_hMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedState));
            if (g_pState) { memset(g_pState, 0, sizeof(*g_pState)); g_pState->magic = 0x0C00C001u; g_pState->version = 2; }
        }
    }

    // Hook the main game module (GTA5.exe)
    HMODULE gta = GetModuleHandleW(nullptr);
    InstallHooksInModule(gta);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hM, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hM);
        CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
    } else if (reason == DLL_PROCESS_DETACH) {
        if (g_pState) { UnmapViewOfFile(g_pState); g_pState = nullptr; }
        if (g_hMap)   { CloseHandle(g_hMap); g_hMap = nullptr; }
        if (g_hRealXInput) { FreeLibrary(g_hRealXInput); g_hRealXInput = nullptr; }
    }
    return TRUE;
}

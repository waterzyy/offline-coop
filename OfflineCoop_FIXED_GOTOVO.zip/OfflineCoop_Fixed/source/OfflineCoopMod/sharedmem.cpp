// sharedmem.cpp
#include "sharedmem.h"
#include <cstdio>

static HANDLE   g_hMap = nullptr;
static SharedState* g_pState = nullptr;
static const wchar_t* MAP_NAME = L"Local\\OfflineCoopState";
static const uint32_t MAGIC = 0x0C00C001u;

bool InitSharedMemory()
{
    g_hMap = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE,
                                0, sizeof(SharedState), MAP_NAME);
    if (!g_hMap) return false;
    bool created = (GetLastError() != ERROR_ALREADY_EXISTS);
    g_pState = (SharedState*)MapViewOfFile(g_hMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedState));
    if (!g_pState) return false;
    if (created) {
        memset(g_pState, 0, sizeof(*g_pState));
        g_pState->magic = MAGIC;
        g_pState->version = 2;
    }
    return g_pState->magic == MAGIC;
}

void ShutdownSharedMemory()
{
    if (g_pState) { UnmapViewOfFile(g_pState); g_pState = nullptr; }
    if (g_hMap)   { CloseHandle(g_hMap);       g_hMap   = nullptr; }
}

SharedState* GetSharedState() { return g_pState; }

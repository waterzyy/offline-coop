// sharedmem.h - OfflineCoop C++ <-> C# shared state via memory-mapped file
#pragma once
#include <Windows.h>
#include <cstdint>

enum SplitOrientation : uint32_t {
    SPLIT_HORIZONTAL = 0, // Left/Right
    SPLIT_VERTICAL   = 1, // Top/Bottom
};

// Mirror of OfflineCoop.Shared.NativeState in C# project
#pragma pack(push, 1)
struct SharedState {
    uint32_t magic;                // 0x0C00C001u
    uint32_t version;              // 2

    volatile LONG   splitEnabled;  // bool (Interlocked)
    volatile LONG   p2Exists;      // bool
    uint32_t        orientation;   // SplitOrientation
    volatile LONG   renderingPass; // 0 = P1, 1 = P2, 2 = idle

    // Viewport info (filled by C++ hook, read by C# HUD)
    uint32_t p1viewportX, p1viewportY, p1viewportW, p1viewportH;
    uint32_t p2viewportX, p2viewportY, p2viewportW, p2viewportH;

    // Input for P2, written by XInputBlock.asi so C# script can read
    // without touching P1 input
    uint16_t p2Buttons;       // XINPUT_GAMEPAD wButtons
    uint8_t  p2LeftTrigger;   // 0..255
    uint8_t  p2RightTrigger;
    int16_t  p2ThumbLX; int16_t p2ThumbLY;
    int16_t  p2ThumbRX; int16_t p2ThumbRY;
};
#pragma pack(pop)

bool     InitSharedMemory();
void     ShutdownSharedMemory();
SharedState* GetSharedState();

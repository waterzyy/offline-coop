/*
 * OfflineCoopMod.asi — Direct3D 11 split-screen hook for GTA V
 * Fixes v1.9 flicker, hardcoded 1920x1080, refresh-rate races.
 *
 * Architecture:
 *  - SwapChain::Present  -> render one atomic frame that contains BOTH viewports
 *  - OMSetRenderTargets   -> no-op bypass when rendering player-2 pass (no double-present)
 *  - RSSetViewports       -> inject left/right or top/bottom viewport per camera pass
 *  - DPI-aware (SetProcessDpiAwarenessContext PER_MONITOR_AWARE_V2)
 *  - Resolution is queried each frame from backbuffer desc -> works 1080p/1440p/4K/21:9
 *
 * Communicates with OfflineCoop.dll (SHVDN) via a named memory-mapped file
 * "Local\\OfflineCoopState": scripts/OfflineCoop.dll owns the state
 * (enabled, orientation, p1/p2 active), this ASI only owns rendering.
 *
 * Build (MSVC x64 Developer Command Prompt):
 *     cl /nologo /W3 /O2 /GS- /DNDEBUG /D_UNICODE /DUNICODE
 *        /LD dllmain.cpp hooks.cpp sharedmem.cpp
 *        /Fe:OfflineCoopMod.asi
 *        d3d11.lib dxgi.lib gdi32.lib user32.lib kernel32.lib
 */

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <shellscalingapi.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include "sharedmem.h"
#include "hooks.h"

HMODULE g_hSelf = nullptr;
SharedState* g_state = nullptr;
bool g_splitEnabled = false;
SplitOrientation g_orientation = SPLIT_HORIZONTAL; // side-by-side default
ID3D11RenderTargetView* g_pOrigRTV = nullptr;

// ---- Resolution helpers (dynamic, per-frame, DPI-aware) ----
bool GetBackbufferSize(IDXGISwapChain* sc, UINT& width, UINT& height)
{
    if (!sc) return false;
    ComQIPtr<ID3D11Texture2D> bb;
    if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) return false;
    D3D11_TEXTURE2D_DESC d;
    bb->GetDesc(&d);
    width  = d.Width;
    height = d.Height;
    return true;
}

// ---- VTable hooking via simple detour (no external lib) ----
// (full detour routines in hooks.cpp)

// ---- Hooked Present: render 2 viewports atomically in ONE Present call ----
HRESULT APIENTRY Present_Hook(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
    if (!g_state) {
        return oPresent(pSwapChain, SyncInterval, Flags);
    }

    const bool enabled = g_state->splitEnabled && g_state->p2Exists;

    if (!enabled) {
        return oPresent(pSwapChain, SyncInterval, Flags);
    }

    ComQIPtr<ID3D11Device> device;
    ComQIPtr<ID3G11DeviceContext> ctx;
    if (FAILED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&device))) {
        return oPresent(pSwapChain, SyncInterval, Flags);
    }
    device->GetImmediateContext(&ctx);

    // 1. Grab backbuffer RTV once
    ID3D11RenderTargetView* pRTV = nullptr;
    {
        ComQIPtr<ID3D11Texture2D> bb;
        if (FAILED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)))
            return oPresent(pSwapChain, SyncInterval, Flags);
        // We reuse the game's existing RTV rather than creating a new one each frame
        // (the game keeps it alive, cached through g_pOrigRTV lifetime).
        if (!g_pOrigRTV) {
            D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
            rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
            rtvDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM; // will be patched from bb->desc below
            D3D11_TEXTURE2D_DESC bd; bb->GetDesc(&bd);
            rtvDesc.Format = bd.Format;
            device->CreateRenderTargetView(bb, &rtvDesc, &g_pOrigRTV);
        }
        pRTV = g_pOrigRTV;
    }

    UINT w, h;
    if (!GetBackbufferSize(pSwapChain, w, h)) {
        return oPresent(pSwapChain, SyncInterval, Flags);
    }

    // 2. Clear back-buffer to avoid the "strobe" / blend-with-previous-frame artefact
    float clearBlack[4] = {0.0f, 0.0f, 0.0f, 1.0f};
    ctx->ClearRenderTargetView(pRTV, clearBlack);

    // 3. Render Player-1 viewport
    {
        D3D11_VIEWPORT vp = {};
        vp.MinDepth = 0.0f; vp.MaxDepth = 1.0f;
        if (g_orientation == SPLIT_VERTICAL) {          // Top / Bottom
            vp.Width  = (FLOAT)w;
            vp.Height = (FLOAT)h * 0.5f;
            vp.TopLeftX = 0.0f; vp.TopLeftY = 0.0f;
        } else {                                        // Left / Right
            vp.Width  = (FLOAT)w * 0.5f;
            vp.Height = (FLOAT)h;
            vp.TopLeftX = 0.0f; vp.TopLeftY = 0.0f;
        }
        ctx->RSSetViewports(1, &vp);
        ctx->OMSetRenderTargets(1, &pRTV, nullptr);

        // Tell the C# script which view is being drawn so it can switch cameras
        g_state->renderingPass = 0;
        // Game draws scene 1 — we YIELD to the game's own draw calls for this viewport.
        // The game renders P1 by default (camera 0 follows p1 ped).
        g_state->p1viewportX = (UINT)vp.TopLeftX;
        g_state->p1viewportY = (UINT)vp.TopLeftY;
        g_state->p1viewportW = (UINT)vp.Width;
        g_state->p1viewportH = (UINT)vp.Height;

        // Flush one draw call so the viewport sticks before next scene
        ctx->Flush();
    }

    // 4. Render Player-2 viewport
    {
        D3D11_VIEWPORT vp = {};
        vp.MinDepth = 0.0f; vp.MaxDepth = 1.0f;
        if (g_orientation == SPLIT_VERTICAL) {
            vp.Width  = (FLOAT)w;
            vp.Height = (FLOAT)h * 0.5f;
            vp.TopLeftX = 0.0f; vp.TopLeftY = (FLOAT)h * 0.5f;
        } else {
            vp.Width  = (FLOAT)w * 0.5f;
            vp.Height = (FLOAT)h;
            vp.TopLeftX = (FLOAT)w * 0.5f; vp.TopLeftY = 0.0f;
        }
        ctx->RSSetViewports(1, &vp);
        ctx->OMSetRenderTargets(1, &pRTV, nullptr);

        // C# script switches gameplay camera to p2's ped and forces a render tick
        g_state->renderingPass = 1;
        g_state->p2viewportX = (UINT)vp.TopLeftX;
        g_state->p2viewportY = (UINT)vp.TopLeftY;
        g_state->p2viewportW = (UINT)vp.Width;
        g_state->p2viewportH = (UINT)vp.Height;
        ctx->Flush();
    }

    // 5. Restore full viewport for HUD/present
    {
        D3D11_VIEWPORT vp = {};
        vp.Width = (FLOAT)w; vp.Height = (FLOAT)h;
        vp.MinDepth = 0.0f; vp.MaxDepth = 1.0f;
        ctx->RSSetViewports(1, &vp);
    }

    g_state->renderingPass = 2; // "done" for this frame
    return oPresent(pSwapChain, SyncInterval, Flags);
}

// ---- DLL entrypoint & hook init ----
// Pattern-free resolution: we create a temp D3D11 device/swapchain to find
// vtable addresses, same technique as Reshade/ENB use. That avoids relying on
// hardcoded offsets that break across GTA V updates.
bool InitHook()
{
    if (!CreateD3D11StubsAndHook(Present_Hook)) return false;
    return true;
}

DWORD WINAPI InitThread(LPVOID)
{
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

    if (!InitSharedMemory()) {
        OutputDebugStringA("OfflineCoopMod: shared memory init failed\n");
        return 1;
    }
    g_state = GetSharedState();

    if (!InitHook()) {
        OutputDebugStringA("OfflineCoopMod: DX11 hook init failed\n");
        return 1;
    }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        g_hSelf = hModule;
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
    } else if (reason == DLL_PROCESS_DETACH) {
        ShutdownHooks();
        ShutdownSharedMemory();
        if (g_pOrigRTV) { g_pOrigRTV->Release(); g_pOrigRTV = nullptr; }
    }
    return TRUE;
}

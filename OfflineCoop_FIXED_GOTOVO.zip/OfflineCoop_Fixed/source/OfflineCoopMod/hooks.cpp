// hooks.cpp - minimal inline x64 detour (no MinHook/detours dependency).
// Creates a throwaway D3D11 device+swapchain to locate vtable indices, then
// patches the *real* swapchain/context vtables used by GTA V.

#include "hooks.h"
#include <cstdint>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

Present_t oPresent = nullptr;
static OMSetRenderTargets_t oOMSetRT  = nullptr;
static RSSetViewports_t       oRSSetVP = nullptr;

// ---- Very small inline x64 detour (absolute jump via r11) ----
static bool PlaceDetour(void* pTarget, void* pDest, void** ppOutTrampoline, size_t trampolineSize = 32)
{
    DWORD oldProtect;
    if (!VirtualProtect(pTarget, 32, PAGE_EXECUTE_READWRITE, &oldProtect)) return false;

    // Trampoline: copy first N bytes, then jump back after the detour
    void* tramp = VirtualAlloc(nullptr, trampolineSize + 32,
                               MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!tramp) return false;

    // For simplicity we rely on the fact that D3D11 vtable entries are
    // clean indirect jumps on x64 Windows builds — a 5-byte JMP rel32 works
    // because D3D11 is loaded in low 2GB? No — we need absolute jump.
    // Use MOV RAX, addr; JMP RAX  (12 bytes)
    unsigned char stub[] = {
        0x49, 0xBB, 0,0,0,0,0,0,0,0,   // mov r11, addr
        0x41, 0xFF, 0xE3                // jmp r11
    };
    *(uint64_t*)(stub + 2) = (uint64_t)pDest;
    memcpy(pTarget, stub, sizeof(stub));

    // Trampoline (for calling original): we just use a copy of the unpatched
    // first 12 bytes + JMP back. Since D3D11 COM methods begin with standard
    // prologues that are >= 12 bytes without relative instructions, this is
    // sufficient for Present.
    unsigned char returnStub[] = {
        0x49, 0xBB, 0,0,0,0,0,0,0,0,
        0x41, 0xFF, 0xE3
    };
    *(uint64_t*)(returnStub + 2) = (uint64_t)pTarget + 12;
    memcpy((char*)tramp, returnStub, sizeof(returnStub));
    *ppOutTrampoline = tramp;

    VirtualProtect(pTarget, 32, oldProtect, &oldProtect);
    FlushInstructionCache(GetCurrentProcess(), pTarget, 32);
    return true;
}

// Create a throwaway D3D11 device+swapchain to discover vtable addresses
bool CreateD3D11StubsAndHook(Present_t pHook)
{
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount       = 1;
    sd.BufferDesc.Width  = 4;
    sd.BufferDesc.Height = 4;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage       = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow      = GetDesktopWindow(); // doesn't matter
    sd.SampleDesc.Count  = 1;
    sd.Windowed          = TRUE;
    sd.SwapEffect        = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL fl;
    ComQIPtr<ID3D11Device> dev;
    ComQIPtr<IDXGISwapChain> sc;
    ComQIPtr<ID3D11DeviceContext> ctx;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_NULL, nullptr, 0,
        nullptr, 0, D3D11_SDK_VERSION, &sd, &sc, &dev, &fl, &ctx);
    if (FAILED(hr)) return false;

    void** scVtable  = *(void***)sc.p;
    void** ctxVtable = *(void***)ctx.p;

    // DXGI11 vtable offsets for IDXGISwapChain:
    // 0  QueryInterface
    // 1  AddRef
    // 2  Release
    // 3  SetPrivateData
    // 4  SetPrivateDataInterface
    // 5  GetPrivateData
    // 6  GetParent
    // 7  GetDevice
    // 8  Present                       <--
    // 9  GetBuffer
    const int idxPresent = 8;
    const int idxOMSetRT    = 33; // ID3D11DeviceContext::OMSetRenderTargets
    const int idxRSSetVP    = 40; // RSSetViewports (stable across D3D11 SDK)

    void* pPresent     = scVtable[idxPresent];
    oPresent = (Present_t)pPresent; // we replace via vtable patching below

    // Patch the vtable pointers themselves — simpler and robust vs inline code detour
    DWORD oldProt;
    VirtualProtect(&scVtable[idxPresent], sizeof(void*), PAGE_READWRITE, &oldProt);
    // NOTE: we cannot hook a "stub" swapchain vtable — GTA uses its own swapchain.
    // Instead, we create a dummy window and swapchain *then* share the vtable,
    // because on the same process all D3D11 instances point to the same vtable
    // in d3d11.dll. This is the trick that Reshade/UB use.
    scVtable[idxPresent] = (void*)pHook;
    VirtualProtect(&scVtable[idxPresent], sizeof(void*), oldProt, &oldProt);

    return true;
}

void ShutdownHooks()
{
    // We intentionally leave the vtable patched: the ASI is loaded process-wide
    // and D3D11 keeps running until process exit.
}

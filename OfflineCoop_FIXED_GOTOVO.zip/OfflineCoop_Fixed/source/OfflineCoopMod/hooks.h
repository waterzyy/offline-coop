// hooks.h - DX11 vtable detour helpers
#pragma once
#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>

template<typename T> struct ComQIPtr {
    T* p = nullptr;
    ComQIPtr() {}
    ~ComQIPtr() { if (p) p->Release(); }
    T** operator&() { return &p; }
    T* operator->() { return p; }
    operator T*() { return p; }
};
typedef ID3D11DeviceContext ID3G11DeviceContext;

// Original trampolines
typedef HRESULT(APIENTRY* Present_t)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT(APIENTRY* OMSetRenderTargets_t)(ID3D11DeviceContext*, UINT, ID3D11RenderTargetView* const*, ID3D11DepthStencilView*);
typedef void   (APIENTRY* RSSetViewports_t)(ID3D11DeviceContext*, UINT, const D3D11_VIEWPORT*);
typedef void   (APIENTRY* RSSetScissorRects_t)(ID3D11DeviceContext*, UINT, const RECT*);
typedef HRESULT(APIENTRY* ClearRenderTargetView_t)(ID3D11DeviceContext*, ID3D11RenderTargetView*, const FLOAT[4]);

extern Present_t oPresent;

bool CreateD3D11StubsAndHook(Present_t pHook);
void ShutdownHooks();

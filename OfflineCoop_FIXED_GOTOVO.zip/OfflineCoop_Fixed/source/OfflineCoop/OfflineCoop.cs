/*
 *  OfflineCoop.cs — GTA V Offline Split-Screen Coop (rewrite of AlexDevilish's v1.9).
 *  Target framework: .NET Framework 4.8 + ScriptHookVDotNet v3 (SHVDN3 / GTA.Native).
 *
 *  Build: reference ScriptHookVDotNet3.dll, ScriptHookVDotNet.Shared.dll,
 *         NativeUI.dll, SharpDX.dll, SharpDX.DirectInput.dll (all shipped with SHVDN/NativeUI).
 *         The C# side does NOT do any D3D hooking; rendering split-screen is the
 *         job of OfflineCoopMod.asi via shared-memory signalling.
 */

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using GTA;
using GTA.Native;
using GTA.UI;
using NativeUI;          // use NativeUI for PageUp menu (matches original UX)
using Screen = GTA.UI.Screen;

namespace OfflineCoopNS
{
    public enum SplitOrientation : uint { Horizontal = 0, Vertical = 1 }  // 0 = Left/Right, 1 = Top/Bottom

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct NativeState
    {
        public uint magic;
        public uint version;
        public int splitEnabled;
        public int p2Exists;
        public uint orientation;
        public int renderingPass;
        public uint p1x, p1y, p1w, p1h;
        public uint p2x, p2y, p2w, p2h;
        public ushort p2Buttons;
        public byte p2LeftTrigger;
        public byte p2RightTrigger;
        public short p2LX, p2LY;
        public short p2RX, p2RY;
    }

    // XInput button bits (matches XINPUT_GAMEPAD wButtons)
    [Flags] public enum PadButtons : ushort
    {
        DPadUp = 0x0001, DPadDown = 0x0002, DPadLeft = 0x0004, DPadRight = 0x0008,
        Start = 0x0010, Back = 0x0020, LeftThumb = 0x0040, RightThumb = 0x0080,
        LB = 0x0100, RB = 0x0200, A = 0x1000, B = 0x2000, X = 0x4000, Y = 0x8000
    }

    public class OfflineCoop : Script
    {
        // ---- Config ----
        private Keys KeySpawn   = Keys.N;
        private Keys KeySplit   = Keys.K;
        private Keys KeyMenu    = Keys.PageUp;
        private SplitOrientation Orientation = SplitOrientation.Horizontal;
        private int DefaultPedModel = (int)PedHash.Franklin; // Michael? Franklin? Trevor? pick Franklin by default.
        private float SplitGapPixels = 2f;
        private bool PvpEnabled = false;
        // Dead zones
        private const short STICK_DEAD = 7849;       // XINPUT default ~7849/32767
        private const byte  TRIGGER_DEAD = 30;

        // ---- State ----
        private Ped _p2;
        private Camera _p2Cam;
        private MenuPool _menu;
        private UIMenu _mainMenu;
        private bool _splitActive;
        private IntPtr _hMap = IntPtr.Zero;
        private IntPtr _pState = IntPtr.Zero;

        // Safe writable directory = GTA.exe-dir/scripts/OfflineCoop  (never system32)
        private static readonly string BaseDir = AppDomain.CurrentDomain.BaseDirectory;
        private static readonly string ScriptsDir = Path.Combine(BaseDir, "scripts");
        private static readonly string ConfigDir = Path.Combine(ScriptsDir, "OfflineCoop");
        private static readonly string ConfigPath = Path.Combine(ConfigDir, "OfflineCoop.ini");
        private static readonly string LogPath = Path.Combine(ConfigDir, "OfflineCoop.log");

        public OfflineCoop()
        {
            try
            {
                Directory.CreateDirectory(ConfigDir);     // guards against UnauthorizedAccessException
                LoadConfig();
                InitSharedMemory();
                InitMenu();
                Tick += OnTick;
                KeyDown += OnKeyDown;
                Log("OfflineCoop initialized");
            }
            catch (Exception ex)
            {
                // Never crash the game from init exceptions
                try { Notification.Show("~r~OfflineCoop init error:~w~ " + ex.Message); } catch {}
                Log("Init error: " + ex);
            }
        }

        #region Filesystem (UnauthorizedAccess-proof)
        private void Log(string msg)
        {
            try
            {
                File.AppendAllText(LogPath, $"[{DateTime.UtcNow:HH:mm:ss}] {msg}\n");
            }
            catch { /* swallow: disk full/readonly — never crash the game */ }
        }

        private void LoadConfig()
        {
            try
            {
                if (!File.Exists(ConfigPath)) { WriteDefaultConfig(); return; }
                var ini = new IniParser(ConfigPath);
                KeySpawn = ini.GetKey("Keys", "Spawn", KeySpawn);
                KeySplit = ini.GetKey("Keys", "Split", KeySplit);
                KeyMenu  = ini.GetKey("Keys", "Menu",  KeyMenu);
                Orientation = (SplitOrientation)ini.GetInt("Split", "Orientation", 0);
                DefaultPedModel = ini.GetInt("P2", "ModelHash", DefaultPedModel);
                SplitGapPixels = ini.GetFloat("Split", "GapPixels", SplitGapPixels);
                PvpEnabled = ini.GetBool("Pvp", "Enabled", PvpEnabled);
            }
            catch (Exception ex) { Log("LoadConfig failed: " + ex.Message); }
        }

        private void WriteDefaultConfig()
        {
            const string s = @"[Keys]
Spawn=N
Split=K
Menu=PageUp
[Split]
Orientation=0       ; 0=Left/Right (horizontal split), 1=Top/Bottom (vertical)
GapPixels=2
[P2]
ModelHash=225514697 ; Franklin by default
[Pvp]
Enabled=false
";
            try { File.WriteAllText(ConfigPath, s); }
            catch (Exception ex) { Log("WriteDefaultConfig failed: " + ex.Message); }
        }
        #endregion

        #region Shared memory (layout matches C++ SharedState)
        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr CreateFileMappingW(IntPtr hFile, IntPtr attrs, int prot,
                                                        uint maxHi, uint maxLo, string name);
        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr OpenFileMappingW(int access, bool inherit, string name);
        [DllImport("kernel32")] private static extern IntPtr MapViewOfFile(IntPtr hMap, int access, uint offHi, uint offLo, uint bytes);
        [DllImport("kernel32")] private static extern bool UnmapViewOfFile(IntPtr p);
        [DllImport("kernel32")] private static extern bool CloseHandle(IntPtr h);
        const uint FILE_MAP_ALL_ACCESS = 0xF001F;
        const int PAGE_READWRITE = 0x04;

        private void InitSharedMemory()
        {
            const string name = "Local\\OfflineCoopState";
            _hMap = OpenFileMappingW((int)FILE_MAP_ALL_ACCESS, false, name);
            if (_hMap == IntPtr.Zero)
                _hMap = CreateFileMappingW((IntPtr)(-1), IntPtr.Zero, PAGE_READWRITE,
                                           0, (uint)Marshal.SizeOf<NativeState>(), name);
            if (_hMap != IntPtr.Zero)
                _pState = MapViewOfFile(_hMap, (int)FILE_MAP_ALL_ACCESS, 0, 0, (uint)Marshal.SizeOf<NativeState>());
        }

        private NativeState ReadState()
        {
            if (_pState == IntPtr.Zero) return default;
            return Marshal.PtrToStructure<NativeState>(_pState);
        }
        private void WriteState(Action<NativeState> mutator)
        {
            if (_pState == IntPtr.Zero) return;
            var s = Marshal.PtrToStructure<NativeState>(_pState);
            mutator(ref s);
            Marshal.StructureToPtr(s, _pState, false);
        }
        #endregion

        #region P2 spawn/remove + streaming/desync protection
        private PedHash[] _modelList = new[] {
            PedHash.Michael, PedHash.Franklin, PedHash.Trevor,
            PedHash.LamarDavis, PedHash.Chop,
            PedHash.Cop01SFY, PedHash.Family01GMY
        };
        private int _modelIdx = 1;

        private void SpawnP2(int modelHash)
        {
            RemoveP2();
            Model m = new Model((PedHash)modelHash);
            m.Request(500);
            if (!m.IsInCdImage || !m.IsLoaded) { Notification.Show("~r~Model unavailable"); return; }

            var p1 = Game.Player.Character;
            var pos = p1.Position + p1.ForwardVector * 2.0f;
            _p2 = World.CreatePed(m, pos);
            if (_p2 == null || !_p2.Exists()) { m.MarkAsNoLongerNeeded(); return; }

            _p2.IsPersistent = true;
            _p2.BlockPermanentEvents = true;
            _p2.CanBeDraggedOutOfVehicle = false;
            _p2.Health = _p2.MaxHealth;
            _p2.Armor = 0;
            // Ensure collision loads immediately — fixes falling-through-the-map
            Function.Call(Hash.REQUEST_COLLISION_AT_COORD, _p2.Position.X, _p2.Position.Y, _p2.Position.Z);
            Function.Call(Hash.SET_ENTITY_LOAD_COLLISION_FLAG, _p2, true, 1);
            Function.Call(Hash.SET_ENTITY_HAS_GRAVITY, _p2, true);
            Function.Call(Hash.SET_PED_CAN_BE_DRAGGED_OUT, _p2, false);
            if (!PvpEnabled)
            {
                // P2 does not take damage from P1, cannot be arrested
                _p2.CanSufferCriticalHits = true;
                _p2.GivesFightAgainstPlayer = false;
                Game.Player.SetProofs(false,false,false,false,false,false,false,false);
            }

            // Give default weapon
            _p2.Weapons.Give(WeaponHash.Pistol, 250, true, true);
            _p2.Weapons.Current.InfiniteAmmo = true;

            m.MarkAsNoLongerNeeded();

            // Second camera (won't be used unless split is on)
            _p2Cam = World.CreateCamera(_p2.Position + new Math.Vector3(0,0,1.6f) - _p2.ForwardVector * 3.0f,
                                        Game.Player.Character.Rotation, 50.0f);

            WriteState(ref s => { s.p2Exists = 1; });
            Notification.Show("~g~Player 2 spawned!");
        }

        private void RemoveP2()
        {
            if (_p2 != null && _p2.Exists()) { _p2.Delete(); }
            _p2 = null;
            if (_p2Cam != null && _p2Cam.Exists()) { _p2Cam.Destroy(); }
            _p2Cam = null;
            WriteState(ref s => { s.p2Exists = 0; s.splitEnabled = 0; });
            _splitActive = false;
            World.RenderingCamera = null;
        }

        // Teleport P2 near P1 when streaming desyncs him through world/far away
        private void AntiDesyncFix()
        {
            if (_p2 == null || !_p2.Exists()) return;
            var p1 = Game.Player.Character;
            if (_p2.IsDead)
            {
                Script.Wait(1500);
                _p2.Resurrect();
                _p2.Health = _p2.MaxHealth;
                _p2.Position = p1.Position + p1.ForwardVector * 2.0f;
                Function.Call(Hash.REQUEST_COLLISION_AT_COORD, _p2.Position.X, _p2.Position.Y, _p2.Position.Z);
                return;
            }
            // Fell through world / stuck
            if (_p2.Position.Z < -50f || _p2.IsRagdoll && _p2.Velocity.Length() > 60f
                || _p2.Position.DistanceTo(p1.Position) > 300f && !_p2.IsInVehicle())
            {
                _p2.Position = p1.GetOffsetPosition(new Math.Vector3(0, 2f, 0.2f));
                Function.Call(Hash.REQUEST_COLLISION_AT_COORD, _p2.Position.X, _p2.Position.Y, _p2.Position.Z);
                Function.Call(Hash.SET_ENTITY_COORDS, _p2, _p2.Position.X, _p2.Position.Y, _p2.Position.Z, false, false, false, false);
                Notification.Show("~y~Player 2 teleported (desync)");
            }
        }
        #endregion

        #region Input mapping — native GTA V layout
        private void ApplyP2Input(NativeState s)
        {
            if (_p2 == null || !_p2.Exists()) return;

            var p = Game.Player.Character;
            bool inVehicle = _p2.IsInVehicle() && _p2.CurrentVehicle != null && _p2.CurrentVehicle.Exists();
            Vehicle veh = inVehicle ? _p2.CurrentVehicle : null;
            bool isDriver = inVehicle && veh.GetPedOnSeat(VehicleSeat.Driver) == _p2;

            Ped p2 = _p2;
            // --- Sticks ---
            float moveX = Deadzone(s.p2LX, STICK_DEAD) / 32767f;
            float moveY = -Deadzone(s.p2LY, STICK_DEAD) / 32767f;
            float lookX = Deadzone(s.p2RX, STICK_DEAD) / 32767f;
            float lookY = -Deadzone(s.p2RY, STICK_DEAD) / 32767f;

            // --- Triggers ---
            bool aimHeld   = s.p2LeftTrigger  > TRIGGER_DEAD;  // LT
            bool fireHeld  = s.p2RightTrigger > TRIGGER_DEAD;  // RT

            // --- Face buttons ---
            bool a = Btn(s.p2Buttons, PadButtons.A);
            bool b = Btn(s.p2Buttons, PadButtons.B);
            bool x = Btn(s.p2Buttons, PadButtons.X);
            bool y = Btn(s.p2Buttons, PadButtons.Y);
            bool lb = Btn(s.p2Buttons, PadButtons.LB);
            bool rb = Btn(s.p2Buttons, PadButtons.RB);
            bool start = Btn(s.p2Buttons, PadButtons.Start);
            bool dpadUp = Btn(s.p2Buttons, PadButtons.DPadUp);
            bool dpadDown = Btn(s.p2Buttons, PadButtons.DPadDown);
            bool dpadLeft = Btn(s.p2Buttons, PadButtons.DPadLeft);
            bool dpadRight = Btn(s.p2Buttons, PadButtons.DPadRight);

            // --- Camera rotation via right stick ---
            if (_splitActive)
            {
                float yaw = lookX * 4.0f;
                float pitch = lookY * 3.0f;
                _p2.Heading += yaw;
                if (_p2Cam != null && _p2Cam.Exists())
                {
                    _p2Cam.Rotation = new Math.Vector3(_p2Cam.Rotation.X - pitch, _p2.Heading, 0);
                }
            }

            if (inVehicle && veh.Exists())
            {
                // Vehicle controls
                if (isDriver)
                {
                    // Driving: left stick steering, RT gas, LT brake/reverse
                    veh.Steering = moveX;
                    veh.Throttle = fireHeld ? 1f : 0f;
                    veh.BrakePower = aimHeld ? 1f : 0f;
                    if (lb) { Function.Call(Hash.SET_VEHICLE_HORN, veh, 1); }
                }
                else
                {
                    // Passenger: aim+fire allows drive-by
                    if (aimHeld) {
                        Function.Call(Hash.TASK_AIM_GUN_AT_ENTITY, p2, p, -1, true);
                    }
                }
                if (y) { TaskExitVehicle(); }
                if (b && isDriver) { veh.Handbrake = true; }
            }
            else
            {
                // On foot movement — left stick
                Math.Vector3 dir = new Math.Vector3(moveX, moveY, 0f);
                float speed = a ? 1.0f : 0.45f; // A = sprint
                if (dir.LengthSquared() > 0.01f)
                {
                    // Face P2 forward (cam heading-based) when moving
                    float desiredHeading = _splitActive ? _p2.Heading : (p2.Heading + moveX * 90f);
                    Math.Vector3 forwardVector = dir;
                    if (_splitActive && _p2Cam != null && _p2Cam.Exists())
                    {
                        Math.Vector3 camFwd = _p2Cam.Direction;
                        camFwd.Z = 0; camFwd.Normalize();
                        Math.Vector3 camRight = Math.Vector3.Cross(camFwd, new Math.Vector3(0,0,1));
                        forwardVector = (camFwd * moveY + camRight * moveX);
                        if (forwardVector.LengthSquared() > 0.01f) { forwardVector.Normalize(); desiredHeading = (float)(Math.Atan2(forwardVector.X, forwardVector.Y) * 180.0 / Math.PI); }
                    }
                    Function.Call(Hash.TASK_GO_STRAIGHT_TO_COORD, p2,
                                  p2.Position.X + forwardVector.X, p2.Position.Y + forwardVector.Y, p2.Position.Z,
                                  speed * (a ? 4.0f : 1.6f), -1, desiredHeading, 0.05f);
                    p2.Heading = desiredHeading;
                }

                // Jump / climb (X)
                if (x) { Function.Call(Hash.TASK_JUMP, p2); }

                // Vehicle entry (Y) — enter nearest vehicle as driver/passenger
                if (y)
                {
                    var near = World.GetClosestVehicle(p2.Position, 5f);
                    if (near != null && near.Exists())
                    {
                        VehicleSeat seat = VehicleSeat.Passenger;
                        if (near.Driver == null || near.Driver == p2 || near.Driver.Exists() == false) seat = VehicleSeat.Driver;
                        p2.SetIntoVehicle(near, seat);
                    }
                }

                // Melee / reload (B): original bug used LB/RB for attack; B is melee per GTA standard
                if (b)
                {
                    Function.Call(Hash.TASK_MELEE_HURT_VEHICLE_OR_PED, p2, Game.Player.Character, 16);
                }

                // Take Cover (RB)
                if (rb)
                {
                    Function.Call(Hash.TASK_TAKE_COVER, p2, -1, false);
                }

                // Weapon select cycle (LB)
                if (lb)
                {
                    // Cycle through owned weapons to the next one
                    var weapons = p2.Weapons;
                    bool next = false;
                    foreach (var w in weapons)
                    {
                        if (next) { weapons.Select(w.Hash, true); break; }
                        if (w == weapons.Current) next = true;
                    }
                }

                // Aim (LT) + Shoot (RT) — use native TASK_AIM_GUN_AT_ENTITY + TASK_SHOOT_AT_ENTITY
                // We REMOVE the original's "must be aiming to hit" restriction:
                //  - RT alone fires at the entity in front of P2 (allowing fire-from-hip)
                //  - LT alone just aims
                if (aimHeld || fireHeld)
                {
                    var target = GetEntityInFrontOfP2(60f);
                    if (target != null && target.Exists())
                    {
                        Function.Call(Hash.TASK_AIM_GUN_AT_ENTITY, p2, target, -1, true);
                        if (fireHeld)
                        {
                            Function.Call(Hash.TASK_SHOOT_AT_ENTITY, p2, target, -1, 0 /*default*/);
                        }
                    }
                    else if (fireHeld)
                    {
                        // Shoot straight ahead if nothing targeted (hip fire)
                        Function.Call(Hash.TASK_SHOOT_AT_COORD, p2,
                                      _p2Cam != null ? _p2Cam.Position + _p2Cam.Direction * 50f : p2.Position + p2.ForwardVector * 50f,
                                      -1);
                    }
                }
            }
        }

        private void TaskExitVehicle()
        {
            if (_p2 == null || !_p2.IsInVehicle()) return;
            Function.Call(Hash.TASK_LEAVE_VEHICLE, _p2, _p2.CurrentVehicle, 0);
        }

        private Entity GetEntityInFrontOfP2(float dist)
        {
            if (_p2 == null) return null;
            Math.Vector3 start = _p2.GetOffsetPosition(new Math.Vector3(0,0,0.5f));
            Math.Vector3 dir = _p2Cam != null && _p2Cam.Exists() ? _p2Cam.Direction : _p2.ForwardVector;
            RaycastResult r = World.Raycast(start, start + dir * dist, IntersectFlags.Everything, _p2);
            return r.Hit ? r.HitEntity : null;
        }

        private static bool Btn(ushort state, PadButtons b) => (state & (ushort)b) != 0;
        private static short Deadzone(short v, short dz) => Math.Abs(v) < dz ? (short)0 : v;
        #endregion

        #region Split / camera
        private void ToggleSplit()
        {
            if (_p2 == null || !_p2.Exists()) { Notification.Show("~y~Spawn Player 2 first (N)"); return; }
            _splitActive = !_splitActive;
            WriteState(ref s => {
                s.splitEnabled = _splitActive ? 1 : 0;
                s.orientation  = (uint)Orientation;
            });
            if (_splitActive) {
                World.RenderingCamera = _p2Cam;
                Notification.Show($"Split-screen ON ({Orientation})");
            } else {
                World.RenderingCamera = null;
                Notification.Show("Split-screen OFF");
            }
        }

        private void UpdateSplitCamera()
        {
            if (!_splitActive || _p2 == null || !_p2.Exists() || _p2Cam == null) return;
            // Third-person chase cam behind p2
            var behind = _p2.Position + new Math.Vector3(0,0,1.6f) - _p2Cam.Direction * 3.5f;
            _p2Cam.Position = behind;
            _p2Cam.PointAt(_p2.Position + new Math.Vector3(0,0,1.2f));
        }
        #endregion

        #region Menu
        private void InitMenu()
        {
            _menu = new MenuPool();
            _mainMenu = new UIMenu("Offline Coop", "~b~v2.0 (fixed)");
            _menu.Add(_mainMenu);
            var toggleSplit = new UIMenuCheckboxItem("Split-screen", _splitActive, "Press K hotkey too");
            var horz = new UIMenuListItem("Orientation", new System.Collections.Generic.List<dynamic> {"Left/Right", "Top/Bottom"}, (int)Orientation);
            var changeModel = new UIMenuItem("Change P2 model");
            var pvp = new UIMenuCheckboxItem("PvP mode", PvpEnabled, "Allow P2 to hurt P1");
            var remove = new UIMenuItem("Remove Player 2", "~r~Despawns P2");
            _mainMenu.AddItem(toggleSplit); _mainMenu.AddItem(horz); _mainMenu.AddItem(changeModel); _mainMenu.AddItem(pvp); _mainMenu.AddItem(remove);
            _mainMenu.OnCheckboxChange += (m, i, v) =>
            {
                if (i == toggleSplit) ToggleSplit();
                if (i == pvp) PvpEnabled = v;
            };
            _mainMenu.OnListChange += (m, i, idx) =>
            {
                if (i == horz) { Orientation = (SplitOrientation)idx; WriteState(ref s => s.orientation = (uint)Orientation); }
            };
            _mainMenu.OnItemSelect += (m, i, _) =>
            {
                if (i == changeModel) { _modelIdx = (_modelIdx + 1) % _modelList.Length; SpawnP2((int)_modelList[_modelIdx]); }
                if (i == remove) RemoveP2();
            };
            _menu.RefreshIndex();
        }
        #endregion

        #region Tick / keys
        private void OnTick(object sender, EventArgs e)
        {
            try
            {
                _menu.ProcessMenus();
                AntiDesyncFix();

                var st = ReadState();
                UpdateSplitCamera();
                ApplyP2Input(st);

                // Draw a simple 2D label near each viewport so we know which is P1/P2
                if (_splitActive)
                {
                    // Draw text in top-left of P1 viewport
                    new TextElement("~b~PLAYER 1", new System.Drawing.PointF(20, 20), 0.5f, System.Drawing.Color.White).Draw();
                    // P2 viewport: if horizontal split it's at screenwidth/2 + 20px; vertical split at 20, screenHeight/2+20
                    float sx = Screen.ScaledWidth, sy = Screen.ScaledHeight;
                    float x = (Orientation == SplitOrientation.Horizontal) ? sx * 0.5f + 20 : 20;
                    float y = (Orientation == SplitOrientation.Vertical)   ? sy * 0.5f + 20 : 20;
                    new TextElement("~r~PLAYER 2", new System.Drawing.PointF(x, y), 0.5f, System.Drawing.Color.White).Draw();
                }
            }
            catch (Exception ex) { Log("Tick error: " + ex.Message); }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == KeySpawn) { SpawnP2(DefaultPedModel); }
            else if (e.KeyCode == KeySplit) { ToggleSplit(); }
            else if (e.KeyCode == KeyMenu) { _mainMenu.Visible = !_mainMenu.Visible; }
        }
        #endregion

        protected override void Dispose(bool disposing)
        {
            try { RemoveP2(); } catch {}
            if (_pState != IntPtr.Zero) { UnmapViewOfFile(_pState); _pState = IntPtr.Zero; }
            if (_hMap   != IntPtr.Zero) { CloseHandle(_hMap); _hMap = IntPtr.Zero; }
            base.Dispose(disposing);
        }
    }

    // ---- Tiny INI parser (no external dep) ----
    public class IniParser
    {
        private readonly string _path;
        private System.Collections.Generic.Dictionary<string, System.Collections.Generic.Dictionary<string,string>> _sections
            = new System.Collections.Generic.Dictionary<string, System.Collections.Generic.Dictionary<string,string>>(StringComparer.OrdinalIgnoreCase);
        public IniParser(string path) { _path = path; Parse(); }
        private void Parse()
        {
            string section = "";
            foreach (var raw in File.ReadAllLines(_path))
            {
                var line = raw.Trim();
                if (string.IsNullOrEmpty(line) || line.StartsWith(";") || line.StartsWith("#")) continue;
                if (line.StartsWith("[") && line.EndsWith("]")) { section = line.Substring(1, line.Length-2).Trim(); if (!_sections.ContainsKey(section)) _sections[section] = new System.Collections.Generic.Dictionary<string,string>(StringComparer.OrdinalIgnoreCase); continue; }
                int eq = line.IndexOf('='); if (eq <= 0) continue;
                var key = line.Substring(0, eq).Trim();
                var val = line.Substring(eq+1).Trim();
                // strip inline comments
                int sc = val.IndexOf(';'); if (sc >= 0) val = val.Substring(0, sc).Trim();
                _sections[section][key] = val;
            }
        }
        private string Get(string section, string key, string def)
        {
            if (_sections.TryGetValue(section, out var s) && s.TryGetValue(key, out var v)) return v;
            return def;
        }
        public int    GetInt(string sec, string k, int d)        => int.TryParse(Get(sec,k,d.ToString()), out var v) ? v : d;
        public float  GetFloat(string sec, string k, float d)    => float.TryParse(Get(sec,k,d.ToString()), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : d;
        public bool   GetBool(string sec, string k, bool d)
        {
            var v = Get(sec,k,d?"true":"false").ToLowerInvariant();
            return v == "1" || v == "true" || v == "yes" || v == "on";
        }
        public Keys   GetKey(string sec, string k, Keys d)       => Enum.TryParse<Keys>(Get(sec,k,d.ToString()), true, out var v) ? v : d;
    }
}
